

from __future__ import annotations

import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

from csi_project.data import make_data_split, make_synthetic_csi
from csi_project.ensemble import evaluate_soft_voting, validation_f1_weights
from csi_project.models import MODEL_NAMES, build_model, count_trainable_parameters


def main() -> None:
    torch.manual_seed(7)
    batch_size, time_steps, subcarriers, classes = 4, 64, 30, 4
    x = torch.randn(batch_size, time_steps, subcarriers)
    y = torch.tensor([0, 1, 2, 3])
    criterion = nn.CrossEntropyLoss()

    for model_name in MODEL_NAMES:
        model = build_model(model_name, subcarriers, classes)
        if model_name == "cnn":
            logits = model(x)
        else:
            logits, attention = model(x, return_attention=True)
            assert attention.shape[0] == batch_size
            assert torch.allclose(
                attention.sum(dim=1),
                torch.ones(batch_size),
                atol=1e-5,
            )
        assert logits.shape == (batch_size, classes)
        loss = criterion(logits, y)
        loss.backward()
        print(
            f"PASS {model_name:24s} "
            f"output={tuple(logits.shape)} "
            f"params={count_trainable_parameters(model):,}"
        )

    bundle = make_synthetic_csi(samples_per_class=20, num_groups=10, seed=7)
    split = make_data_split(bundle, seed=7)
    train_groups = set(bundle.groups[split.train].tolist())
    validation_groups = set(bundle.groups[split.validation].tolist())
    test_groups = set(bundle.groups[split.test].tolist())
    assert train_groups.isdisjoint(validation_groups)
    assert train_groups.isdisjoint(test_groups)
    assert validation_groups.isdisjoint(test_groups)
    print("PASS group-based split has no group overlap")

    class FixedClassifier(nn.Module):
        def __init__(self, logits: list[float]) -> None:
            super().__init__()
            self.register_buffer("fixed_logits", torch.tensor(logits))

        def forward(self, values: torch.Tensor) -> torch.Tensor:
            return self.fixed_logits.repeat(values.shape[0], 1)

    ensemble_loader = DataLoader(
        TensorDataset(torch.zeros(3, 8, 2), torch.ones(3, dtype=torch.long)),
        batch_size=3,
    )
    ensemble_metrics, _ = evaluate_soft_voting(
        [
            FixedClassifier([0.0, 4.0]),
            FixedClassifier([0.0, 3.0]),
            FixedClassifier([3.0, 0.0]),
        ],
        ensemble_loader,
        ["normal", "risk"],
        torch.device("cpu"),
        validation_f1_weights([0.9, 0.8, 0.2]),
    )
    assert ensemble_metrics["accuracy"] == 1.0
    assert abs(sum(ensemble_metrics["ensemble_weights"]) - 1.0) < 1e-9
    print("PASS three-model weighted soft voting")


if __name__ == "__main__":
    main()
