# WiFi CSI 병상 상태 분류 모델 비교



동일한 CSI 입력과 학습 조건에서 다음 세 모델을 비교하고, 세 모델의
확률을 결합한 앙상블까지 같은 테스트셋에서 평가한다.

1. Plain 1D-CNN
2. CNN-BiLSTM-Attention
3. TCN-Attention

추가 평가 방식

4. 동일 가중치 소프트 보팅: 세 모델의 상태별 확률을 1/3씩 평균
5. 검증 성능 가중 소프트 보팅: validation Macro-F1 비율로 가중 평균

가중치는 테스트 결과가 아닌 validation 결과로만 결정하여 테스트셋
정보가 최종 모델 선택에 섞이지 않도록 한다.

현재는 실제 측정 데이터가 없어 `empty`, `still`, `moving`, `bed\_exit` 네 상태를 흉내 낸 합성 데이터 포함

합성 데이터의 정확도는 실제 시스템 성능을 의미하지 않으므로, 코드 검증 용도로만 사용할 것!!



#### 1\. 입력 규격

* 모든 모델은 동일한 입력을 사용함
X shape = \[N, T, S]
N: window 개수
T: window당 시간 sample 수
S: CSI subcarrier 수

y shape = \[N] 또는 \[N, 1]
groups shape = \[N] 또는 \[N, 1]

* 'groups'에는 subject, session 또는 trial ID 입력

  * 같은 측정 회차에서 생성된 인접 window가 train과 test에 동시에 들어가는 데이터 누수 방지 위함
  * groups`가 있으면 group 단위로 분할하고, 없으면 stratified random split을 사용하면서 경고 출력

CSI는 amplitude만 사용



#### 2\. 설치와 동작 확인

* Python 3.10 이상 환경 권장
* smoke\_test.py는 세 모델의 출력 형상, Attention weight 합, 역전파, group 분할 누수 확인



#### 3\. 합성 데이터로 세 모델 실행

* 빠른 1회 확인: python train\_compare.py --data synthetic --epochs 10 --seeds 42
* 최종 비교용 5회 반복: python train\_compare.py --data synthetic --epochs 30 --seeds 0 1 2 3 4 --output-dir outputs/synthetic\_5seeds
* 세 모델과 두 앙상블은 각 seed에서 완전히 동일한 train/validation/test index 사용
* 기존처럼 단일 모델 비교만 하려면 `--disable-ensemble` 사용



#### 4\. 실제 MATLAB 데이터 사용 시

* MATLAB에서 다음 변수로 저장

  * X: \[N, T, S], y: \[N, 1], groups: \[N, 1]
  * save('csi\_dataset.mat', 'X', 'y', 'groups', '-v7');
* MATLAB `-v7.3` 파일은 기본 `scipy.io.loadmat`으로 읽을 수 없으므로 우선 `-v7`을 사용해야 함

python train\_compare.py ^
  --data csi\_dataset.mat ^
  --x-order NTS ^
  --class-names empty still moving bed\_exit ^
  --epochs 50 ^
  --seeds 0 1 2 3 4 ^
  --output-dir outputs/real\_csi

(PowerShell에서 실행할 경우 한 줄로 실행)

* 저장된 X가 \[T, S, N]이면 --x-order TSN, \[S, T, N]이면 --x-order STN처럼 현재 축 순서를 지정 --> 코드 내부에서는 항상 \[N, T, S]로 변환됨
* NPZ 파일도 같은 key 사용

np.savez("csi\_dataset.npz", X=X, y=y, groups=groups)


#### 5\. 결과 파일

* 실행 후 지정한 output directory에 다음 파일 생성

  * `results\_summary.csv`: 단일 모델 및 앙상블별 평균과 표준편차
  * `results\_raw.csv`: seed별 상세 성능
  * `results.json`: 전체 결과
  * `confusion\_matrices/`: 모델별 confusion matrix PNG/CSV
  * `history/`: epoch별 loss와 Macro-F1
  * `checkpoints/`: validation Macro-F1이 가장 높은 모델 weight
  * `split\_seed\_\*.npz`: 재현 가능한 train/validation/test index
  * `run\_metadata.json`: 입력 크기와 실행 인자

기본 평가지표: Accuracy, Balanced Accuracy, Macro-F1, 클래스별 Precision/Recall/F1, parameter 수, 학습 시간 및 sample당 추론 시간

최종 방식은 실제 CSI 데이터 결과에서 위험 상태(`bed_exit`, `moving`) 재현율과
Macro-F1을 우선 비교해 결정한다. 앙상블이 단일 최고 모델보다 낮으면 기존의
단일 체크포인트를 선택할 수 있도록 세 모델의 개별 결과와 체크포인트도 유지한다.

#### 6. 학습된 앙상블로 새 CSI 데이터 추론

학습이 끝나면 `ensemble_seed_42.json` 같은 manifest가 생성된다. 여기에는 세
체크포인트 경로와 동일 가중치, validation Macro-F1 기반 가중치가 들어 있다.

```powershell
python ensemble_predict.py --manifest outputs/ensemble_example/ensemble_seed_42.json --input csi_dataset.npz --output outputs/predictions.jsonl
```

기본값은 validation 가중 소프트 보팅이다. 세 모델을 정확히 1/3씩 반영하려면
`--weights equal`을 추가한다. 출력 JSONL에는 최종 상태와 확률뿐 아니라 각 모델의
개별 판단도 함께 기록되므로 앙상블 판단 근거를 확인할 수 있다.
