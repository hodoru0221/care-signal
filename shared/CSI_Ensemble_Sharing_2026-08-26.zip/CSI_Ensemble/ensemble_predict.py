"""학습된 세 CSI 모델의 소프트 보팅으로 새 측정 데이터를 분류한다."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np
import torch
from scipy.io import loadmat

from csi_project.ensemble import normalize_weights
from csi_project.models import build_model


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--input", required=True, help="X가 들어 있는 .npz 또는 MATLAB -v7 .mat")
    parser.add_argument("--output", default="outputs/ensemble_predictions.jsonl")
    parser.add_argument("--x-key", default="X")
    parser.add_argument("--x-order", default="NTS")
    parser.add_argument("--weights", choices=["validation", "equal"], default="validation")
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--batch-size", type=int, default=64)
    return parser.parse_args()


def load_windows(path: Path, key: str, order: str) -> np.ndarray:
    if path.suffix.lower() == ".npz":
        with np.load(path, allow_pickle=False) as data:
            if key not in data:
                raise ValueError(f"{path.name}에 {key!r} 배열이 없습니다.")
            windows = np.asarray(data[key], dtype=np.float32)
    elif path.suffix.lower() == ".mat":
        data = loadmat(path)
        if key not in data:
            raise ValueError(f"{path.name}에 {key!r} 배열이 없습니다.")
        windows = np.asarray(data[key], dtype=np.float32)
    else:
        raise ValueError("입력은 .npz 또는 MATLAB -v7 .mat 파일이어야 합니다.")
    normalized_order = order.upper()
    if windows.ndim != 3 or sorted(normalized_order) != ["N", "S", "T"]:
        raise ValueError("X는 3차원이어야 하고 x-order에는 N, T, S가 한 번씩 있어야 합니다.")
    windows = np.transpose(windows, [normalized_order.index(axis) for axis in "NTS"])
    if not np.isfinite(windows).all():
        raise ValueError("X에 NaN 또는 무한대 값이 있습니다.")
    return np.ascontiguousarray(windows)


def load_ensemble(manifest_path: Path, device: torch.device) -> tuple[list[Any], dict[str, Any]]:
    with manifest_path.open("r", encoding="utf-8") as file:
        manifest = json.load(file)
    class_names = manifest.get("class_names")
    model_entries = manifest.get("models")
    if not class_names or not isinstance(model_entries, list) or len(model_entries) < 2:
        raise ValueError("manifest에 class_names와 두 개 이상의 models가 필요합니다.")
    loaded: list[Any] = []
    reference: dict[str, Any] | None = None
    for entry in model_entries:
        checkpoint_path = manifest_path.parent / entry["checkpoint"]
        checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=True)
        metadata = checkpoint.get("metadata", {})
        if checkpoint.get("class_names") != class_names:
            raise ValueError(f"클래스 순서가 다른 체크포인트입니다: {checkpoint_path.name}")
        current = {
            "num_subcarriers": int(metadata.get("num_subcarriers", 0)),
            "mean": np.asarray(metadata.get("normalization_mean"), dtype=np.float32),
            "std": np.asarray(metadata.get("normalization_std"), dtype=np.float32),
        }
        if reference is None:
            reference = current
        elif (
            current["num_subcarriers"] != reference["num_subcarriers"]
            or not np.allclose(current["mean"], reference["mean"])
            or not np.allclose(current["std"], reference["std"])
        ):
            raise ValueError("세 모델의 입력 크기 또는 정규화 통계가 서로 다릅니다.")
        model = build_model(
            metadata["model_name"], current["num_subcarriers"], len(class_names)
        ).to(device)
        model.load_state_dict(checkpoint["model_state_dict"])
        model.eval()
        loaded.append(model)
    assert reference is not None
    manifest["input"] = reference
    return loaded, manifest


def main() -> None:
    args = parse_args()
    if args.batch_size < 1:
        raise ValueError("batch-size는 1 이상이어야 합니다.")
    device = torch.device(args.device)
    manifest_path = Path(args.manifest)
    models, manifest = load_ensemble(manifest_path, device)
    windows = load_windows(Path(args.input), args.x_key, args.x_order)
    input_info = manifest["input"]
    num_subcarriers = input_info["num_subcarriers"]
    if windows.shape[2] != num_subcarriers:
        raise ValueError(
            f"모델은 subcarrier {num_subcarriers}개를 요구하지만 입력은 {windows.shape[2]}개입니다."
        )
    mean = input_info["mean"]
    std = input_info["std"]
    windows = (windows - mean[None, None, :]) / np.maximum(std[None, None, :], 1e-6)
    weight_key = "validation_weights" if args.weights == "validation" else "equal_weights"
    weights = normalize_weights(manifest[weight_key], len(models))
    class_names = manifest["class_names"]
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    written = 0
    with output.open("w", encoding="utf-8") as destination, torch.inference_mode():
        for start in range(0, len(windows), args.batch_size):
            batch = torch.from_numpy(windows[start : start + args.batch_size]).to(device)
            combined = None
            individual = []
            for weight, model in zip(weights, models):
                probabilities = torch.softmax(model(batch), dim=1)
                individual.append(probabilities.cpu().numpy())
                weighted = probabilities * float(weight)
                combined = weighted if combined is None else combined + weighted
            assert combined is not None
            combined_np = combined.cpu().numpy()
            for offset, scores in enumerate(combined_np):
                prediction = int(scores.argmax())
                row = {
                    "sequence_no": start + offset,
                    "state": class_names[prediction],
                    "confidence": float(scores[prediction]),
                    "probabilities": {
                        name: float(scores[index]) for index, name in enumerate(class_names)
                    },
                    "model_predictions": [
                        {
                            "model": entry["name"],
                            "state": class_names[int(values[offset].argmax())],
                            "confidence": float(values[offset].max()),
                        }
                        for entry, values in zip(manifest["models"], individual)
                    ],
                    "ensemble": args.weights,
                }
                destination.write(json.dumps(row, ensure_ascii=False) + "\n")
                written += 1
    print(f"predicted={written} output={output.resolve()} weights={weights.tolist()}")


if __name__ == "__main__":
    main()
