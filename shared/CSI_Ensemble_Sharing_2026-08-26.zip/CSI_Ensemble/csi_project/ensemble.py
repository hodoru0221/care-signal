"""세 CSI 분류기의 확률을 결합하는 소프트 보팅 평가 도구."""

from __future__ import annotations

import time
from typing import Any, Sequence

import numpy as np
import torch
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    confusion_matrix,
    precision_recall_fscore_support,
)
from torch import nn
from torch.utils.data import DataLoader


def normalize_weights(weights: Sequence[float], model_count: int) -> np.ndarray:
    values = np.asarray(weights, dtype=np.float64)
    if values.shape != (model_count,):
        raise ValueError(f"앙상블 가중치는 모델 수({model_count})와 같아야 합니다.")
    if not np.isfinite(values).all() or np.any(values < 0):
        raise ValueError("앙상블 가중치는 0 이상의 유한한 값이어야 합니다.")
    total = float(values.sum())
    if total <= 0:
        raise ValueError("앙상블 가중치 합은 0보다 커야 합니다.")
    return values / total


def validation_f1_weights(validation_scores: Sequence[float]) -> np.ndarray:
    """테스트셋 누수 없이 validation Macro-F1로 가중치를 정한다."""
    scores = np.asarray(validation_scores, dtype=np.float64)
    scores = np.maximum(scores, 0.0)
    if float(scores.sum()) <= 0:
        scores = np.ones_like(scores)
    return normalize_weights(scores, len(scores))


def evaluate_soft_voting(
    models: Sequence[nn.Module],
    loader: DataLoader,
    class_names: Sequence[str],
    device: torch.device,
    weights: Sequence[float],
) -> tuple[dict[str, Any], np.ndarray]:
    """모델별 softmax 확률의 가중 평균으로 최종 클래스를 결정한다."""
    if not models:
        raise ValueError("앙상블에는 하나 이상의 모델이 필요합니다.")
    normalized_weights = normalize_weights(weights, len(models))
    for model in models:
        model.eval()

    all_true: list[np.ndarray] = []
    all_predicted: list[np.ndarray] = []
    started = time.perf_counter()
    with torch.inference_mode():
        for x, y in loader:
            x = x.to(device, non_blocking=True)
            probability_sum = None
            for weight, model in zip(normalized_weights, models):
                probability = torch.softmax(model(x), dim=1)
                weighted = probability * float(weight)
                probability_sum = weighted if probability_sum is None else probability_sum + weighted
            assert probability_sum is not None
            all_true.append(y.numpy())
            all_predicted.append(probability_sum.argmax(dim=1).cpu().numpy())
    elapsed = time.perf_counter() - started

    true = np.concatenate(all_true)
    predicted = np.concatenate(all_predicted)
    labels = np.arange(len(class_names))
    precision, recall, f1, support = precision_recall_fscore_support(
        true,
        predicted,
        labels=labels,
        average=None,
        zero_division=0,
    )
    confusion = confusion_matrix(true, predicted, labels=labels)
    metrics: dict[str, Any] = {
        "accuracy": float(accuracy_score(true, predicted)),
        "balanced_accuracy": float(balanced_accuracy_score(true, predicted)),
        "macro_f1": float(np.mean(f1)),
        "trainable_parameters": int(
            sum(parameter.numel() for model in models for parameter in model.parameters())
        ),
        "inference_ms_per_sample": 1000.0 * elapsed / len(true),
        "training_seconds": 0.0,
        "ensemble_weights": normalized_weights.tolist(),
        "per_class": {
            name: {
                "precision": float(precision[index]),
                "recall": float(recall[index]),
                "f1": float(f1[index]),
                "support": int(support[index]),
            }
            for index, name in enumerate(class_names)
        },
    }
    return metrics, confusion
